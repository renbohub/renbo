   
    <?php $__env->startSection('content'); ?>
        <div class="container-fluid bg-white">
            <div class="row pt-4">
                
              <div class="col-6">
                <h4><a href="<?php echo e(route('add.user.action')); ?>" class="btn btn-success add-button" id="addButton">NEW</a> &nbsp; Edit List User &nbsp;&nbsp;</h4>
                
              </div>
              <div class="col-6 text-right">
                
              </div>
              <div class="col-12">
                <hr>
              </div>
                <table  id="data-table" class="table bg-white">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Username</th>
                            <th>Roles Account</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e($row->username); ?></td>
                                <td><?php echo e($row->role_name); ?></td>
                                <td>  
                                    <div class="row">
                                        <div class="col-6 text-right">
                                    
                                            <form action="<?php echo e(route('edit.user.detail')); ?>" method="POST" id="report_option">
                                                <?php echo csrf_field(); ?>
                                                
                                                <input type="hidden" class="form-control"  name="id" value="<?php echo e($row->id); ?>">
                                                <button type="submit" class="btn btn-warning" id="submitBtn">Edit</button>
                                            </form>
                                            
                                        </div>
                                        <div class="col-6">
                                            <?php if($row->username != 'superadmin'): ?>
                                            <form action="<?php echo e(route('delete.user.action')); ?>" method="POST" id="report_option">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" class="form-control"  name="id" value="<?php echo e($row->id); ?>">
                                                <button type="submit" class="btn btn-danger" id="submitBtn">Delete</button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Add the modal markup -->
              
                
       
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\renbo\laravel\resources\views/page/v_edit_user.blade.php ENDPATH**/ ?>