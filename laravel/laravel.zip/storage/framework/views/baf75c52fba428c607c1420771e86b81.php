   
    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row pt-4">
                
              <div class="col-6">
                <h4><button class="btn btn-success add-button" id="addButton">NEW</button> &nbsp; Add User&nbsp;&nbsp;</h4>
                
              </div>
              <div class="col-6 text-right">
                
              </div>
              <div class="col-12">
                <hr>
              </div>
              <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                 
                  <div class="card-body">
                    <form action="<?php echo e(route('add.user.act')); ?>" method="post" id="report_option">
                      <?php echo csrf_field(); ?>
                      
                      <input type="hidden" class="form-control"  name="id" >
                        <label for="year" class="form-label">Username</label>
                        <input type="text" class="form-control"  name="username">
                        
                        <div class="mb-3" id="year">
                            <label for="year" class="form-label">Password</label>
                            <input type="password" class="form-control"  name="password">
                        </div>

                        <div class="mb-3" id="year">
                            <label for="year" class="form-label">Roles</label>
                            <select class="form-control" aria-label="Default select example" name="role">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($r->role_id); ?>"><?php echo e($r->role_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                      
                      <div class="mb-3" id="year">
                        <button type="submit" class="btn btn-success" id="submitBtn">Submit</button>
                      </div>
                      
                      
                      
                     
                    </form>
                     
                  </div>
                  <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- Add the modal markup -->
                

        <script>
        
        </script>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\renbo\laravel\resources\views/page/v_add_user.blade.php ENDPATH**/ ?>