   
    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row pt-4">
                
              <div class="col-6">
                <h4><button class="btn btn-success add-button" id="addButton">NEW</button> &nbsp; Edit User Password&nbsp;&nbsp;</h4>
                
              </div>
              <div class="col-6 text-right">
                
              </div>
              <div class="col-12">
                <hr>
              </div>
              <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                 
                  <div class="card-body">
                    <form action="<?php echo e(route('edit.user.detail.action')); ?>" method="post" id="report_option">
                      <?php echo csrf_field(); ?>
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <input type="hidden" class="form-control"  name="id" value="<?php echo e($s->id); ?>">
                        <label for="year" class="form-label">Username</label>
                        <input type="text" class="form-control"  name="username" value="<?php echo e($s->username); ?>" disabled>
                        
                        <div class="mb-3" id="year">
                            <label for="year" class="form-label">Password</label>
                            <input type="password" class="form-control"  name="password" required>
                        </div>
                      
                      <div class="mb-3" id="year">
                        <button type="submit" class="btn btn-success" id="submitBtn">Submit</button>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                     
                    </form>
                     
                  </div>
                  <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- Add the modal markup -->
                

        <script>
        
        </script>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\renbo\laravel\resources\views/page/v_edit_user_detail.blade.php ENDPATH**/ ?>