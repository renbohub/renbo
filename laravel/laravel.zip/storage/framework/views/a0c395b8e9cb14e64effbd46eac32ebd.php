   
    <?php $__env->startSection('content'); ?>
        <br>
        <br>
        <div class="container bg-white pt-2">
            <div class="row pt-4">
                
              <div class="col-6">
                <h4> &nbsp; Add Permission &nbsp;&nbsp;</h4>
                
              </div>
              <div class="col-6 text-right">
                
              </div>
              <div class="container">
                <div class="col-12 pt-4">
                  <form action="<?php echo e(route('edit.permission.detail.act')); ?>" method="post" id="report_option">
                      <?php echo csrf_field(); ?>
                      
                      <div class="mb-3" id="year">
                        
                        
                        <div class="mb-3" id="year">
                            <label for="year" class="form-label">Select role</label>
                            <select class="form-control" aria-label="Default select example" name="role_id">
                              <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($r1->role_id); ?>"><?php echo e($r1->role_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                             
                            </select>
                        </div>
                        <div class="mb-3" id="year">
                            <label for="year" class="form-label">Select route</label>
                            <select class="form-control" aria-label="Default select example" name="route_id">
                              <?php $__currentLoopData = $route; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($r2->route_id); ?>"><?php echo e($r2->route_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                     
                      <div class="mb-3" id="year">
                        <button type="submit" class="btn btn-success" id="submitBtn">Submit</button>
                      </div>
                     
                      
                      
                     
                    </form>
                </div>
              </div>
             
               
            </div>
        </div>
        <!-- Add the modal markup -->
                

        <script>
        
        </script>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\renbo\laravel\resources\views/page/v_edit_permission_detail.blade.php ENDPATH**/ ?>