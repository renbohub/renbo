   
    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row pt-4">
                
              <div class="col-6">
                <h4><a href="<?php echo e(route('edit.permission.detail')); ?>"class="btn btn-success add-button" id="addButton">NEW</a> &nbsp; Edit List Area &nbsp;&nbsp;</h4>
                
              </div>
              <div class="col-6 text-right">
                
              </div>
              <div class="col-12">
                <hr>
              </div>
                <table  id="data-table" class="table">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Route Name</th>
                        <th>Permission Id</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               <td> <?php echo e($s->permission_id); ?></td>
                               <td> <?php echo e($s->route_name); ?></td>
                               <td> <?php echo e($s->role_name); ?></td>
                               <td><form action="<?php echo e(route('edit.permission.action')); ?>" method="POST" id="report_option">
                                        <?php echo csrf_field(); ?>
                                         <input type="hidden" class="form-control"  name="id" value="<?php echo e($s->permission_id); ?>">
                                        <button type="submit" class="btn btn-success" id="submitBtn">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Add the modal markup -->
                

        <script>
        
        </script>
 <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\renbo\laravel\resources\views/page/v_edit_permission.blade.php ENDPATH**/ ?>